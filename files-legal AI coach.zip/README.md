# Legal AI Coach

Empowering Pro Per/Pro Se litigants in dependency and family law.  
Provides jurisdiction-specific legal analysis, case management, progress tracking, and actionable tips.

## Features

- **Jurisdiction-specific advice** (state/county/federal)
- **Court rule and case law lookup** (API integrations planned)
- **Fact analysis and progress tracking**
- **Goal, contact, document, and timestamp management**
- **Insightful tips & clarifying questions for accuracy**
- **Frontend:** React web app (mobile coming soon)
- **Backend:** Python FastAPI + LangChain (Gemini 2.0, Lexis+, Harvey API integrations planned)

## Getting Started

1. `cd backend && pip install -r requirements.txt`
2. `uvicorn app:app --reload`
3. Set up React frontend in `/frontend`
4. Configure AI and case law APIs as available

---

## Next Steps

- Integrate Gemini 2.0 API for legal analysis
- Connect to court rules and case law databases/APIs
- Build out React chat interface and progress tracker
- Add goal, contact, document, timestamp management
- Enhance insight/tips logic

---

**Contributing:**  
PRs and issue reports welcome!