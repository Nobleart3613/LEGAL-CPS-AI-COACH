import React from "react";

function App() {
  return (
    <div>
      <h1>Legal AI Coach</h1>
      {/* Chat interface, goals tracker, timeline, document upload, etc. */}
      <p>Welcome to the legal AI coach. Chat with your agent, track goals, upload documents, and manage your case here.</p>
    </div>
  );
}

export default App;