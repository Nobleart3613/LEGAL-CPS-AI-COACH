import React from "react";

const SavedChats = () => (
  <div>
    <h3>Saved Chats</h3>
    <ul>
      <li>Chat from 2025-09-01</li>
      <li>Chat from 2025-09-05</li>
    </ul>
  </div>
);

export default SavedChats;