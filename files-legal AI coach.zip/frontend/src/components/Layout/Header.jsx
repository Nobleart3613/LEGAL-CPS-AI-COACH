import React from "react";

const Header = () => (
  <header className="header">
    <h1>Legal AI Coach</h1>
  </header>
);

export default Header;