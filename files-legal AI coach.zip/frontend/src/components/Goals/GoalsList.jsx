import React from "react";

const GoalsList = () => (
  <div>
    <h3>Your Goals</h3>
    {/* Render goals here */}
    <ul>
      <li>Sample goal 1</li>
      <li>Sample goal 2</li>
    </ul>
  </div>
);

export default GoalsList;