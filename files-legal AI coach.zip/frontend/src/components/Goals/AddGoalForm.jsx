import React from "react";

const AddGoalForm = () => (
  <form>
    <input type="text" placeholder="Add new goal" />
    <button type="submit">Add Goal</button>
  </form>
);

export default AddGoalForm;