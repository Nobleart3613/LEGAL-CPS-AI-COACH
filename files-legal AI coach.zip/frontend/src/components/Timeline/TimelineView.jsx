import React from "react";

const TimelineView = () => (
  <div>
    <h3>Case Timeline</h3>
    {/* Timeline steps will be rendered here */}
    <ul>
      <li>Step 1: Case started</li>
      <li>Step 2: Documents uploaded</li>
    </ul>
  </div>
);

export default TimelineView;