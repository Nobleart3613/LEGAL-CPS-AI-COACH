import React from "react";

const DocumentList = () => (
  <div>
    <h3>Uploaded Documents</h3>
    <ul>
      <li>CaseSummary.pdf</li>
      <li>EvidencePhoto.jpg</li>
    </ul>
  </div>
);

export default DocumentList;