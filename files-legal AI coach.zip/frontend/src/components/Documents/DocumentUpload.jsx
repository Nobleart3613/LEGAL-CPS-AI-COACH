import React from "react";

const DocumentUpload = () => (
  <form>
    <input type="file" />
    <button type="submit">Upload Document</button>
  </form>
);

export default DocumentUpload;