import React from "react";

const EvidenceList = () => (
  <div>
    <h3>Uploaded Evidence Photos</h3>
    <ul>
      <li>Photo1.jpg</li>
      <li>Photo2.png</li>
    </ul>
  </div>
);

export default EvidenceList;