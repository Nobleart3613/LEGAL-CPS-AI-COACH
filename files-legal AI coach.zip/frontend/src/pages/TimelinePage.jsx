import React from "react";
import TimelineView from "../components/Timeline/TimelineView";

const TimelinePage = () => (
  <section>
    <h2>Timeline</h2>
    <TimelineView />
  </section>
);

export default TimelinePage;