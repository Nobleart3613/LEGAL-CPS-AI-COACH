import React from "react";

const Dashboard = () => (
  <section>
    <h2>Dashboard</h2>
    <p>Welcome to your Legal AI Coach dashboard. Here you can track your goals, case timeline, documents, chats, and evidence.</p>
  </section>
);

export default Dashboard;