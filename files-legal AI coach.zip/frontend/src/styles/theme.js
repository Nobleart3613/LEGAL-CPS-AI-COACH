// Example theme object for custom styling (expand as needed)
const theme = {
  colors: {
    primary: "#273c75",
    secondary: "#dcdde1",
    accent: "#fbc531",
    background: "#f5f6fa",
    text: "#353b48"
  }
};

export default theme;