# Legal AI Coach Frontend

This is the React frontend for the Legal AI Coach. It provides a dashboard and case tracking tools for goals, timeline, documents, chats, and evidence.

## Features

- Goals tracker and timeline
- Document upload and view
- Chat window and saved chats
- Evidence photo upload and view
- Modular component structure for scalability

## Getting Started

```bash
cd frontend
npm install
npm start
```

## File Structure

- `src/components` — modular components for each main feature
- `src/pages` — route-level pages for navigation
- `src/hooks` — custom hooks for state logic
- `src/context` — context for global state
- `src/styles` — main CSS and theme